export const FACULTIES = [
  'Technology', 'Arts', 'Agriculture', 'Science', 'EDM', 'Health Science',
  'Education', 'Social Science', 'Administration', 'Law'
];
